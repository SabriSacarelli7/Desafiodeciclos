let numero = parseInt(prompt("Ingrese un numero"))

for(let i = 0; i <= numero; i++) {
    
    if(i === 12) {
        continue
    }

    if(i % 2 === 0) {
        console.log(i)
    }
}